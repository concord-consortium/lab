package com.xebec.fractal;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.awt.image.BufferedImageOp;
import java.awt.image.ConvolveOp;
import java.awt.image.Kernel;
import java.awt.image.LookupOp;
import java.awt.image.MemoryImageSource;
import java.awt.image.ShortLookupTable;
import java.util.Hashtable;

import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.ImageIcon;
import javax.swing.JComponent;

/** Render the Mandelbrot set within a certain range on a JComponent.
 *
 *  @author Qian Xie
 */

public class Mandelbrot extends JComponent implements Runnable {

    private final static Cursor waitCursor=new Cursor(Cursor.WAIT_CURSOR);
    private final static Cursor defaultCursor=new Cursor(Cursor.DEFAULT_CURSOR);

    private Font font=new Font("TimesRoman", Font.BOLD, 25);

    private Thread mainThread;
    private int actionID;
    private int index;
    private boolean showWaitMessage;
    private int sleepTime = 10;

    public static final int MOVE_EAST_ID=2001;
    public static final int MOVE_WEST_ID=2002;
    public static final int MOVE_NORTH_ID=2003;
    public static final int MOVE_SOUTH_ID=2004;
    public static final int INVERT_ID=3001;
    public static final int SHARPEN_ID=3002;
    public static final int BLUR_ID=3003;
    public static final int EDGE_ID=3004;
    public static final int POSTER_ID=3005;
    public static final int THRESHOLD_ID=3006;    

    public Action pause=new AbstractAction(){
	    public void actionPerformed(ActionEvent e){
		stop();
	    }
	    public Object getValue(String key){
		if(key==null) return null;
		if(key.equals(SMALL_ICON)) {
		    return new ImageIcon
			(getClass().getResource("images/pause.gif"));
		} else if(key.equals(NAME)){
		    return "Stop";
		}
		return null;
	    }
	};

    public Action moveEast=new AbstractAction(){
	    public void actionPerformed(ActionEvent e){
		actionID=MOVE_EAST_ID;
		if(isStopped()) start();
	    }
	    public Object getValue(String key){
		if(key==null) return null;
		if(key.equals(SMALL_ICON)) {
		    return new ImageIcon
			(getClass().getResource("images/right.gif"));
		} else if(key.equals(SHORT_DESCRIPTION)){
		    return "Move eastward";
		}
		return null;
	    }
	};

    public Action moveWest=new AbstractAction(){
	    public void actionPerformed(ActionEvent e){
		actionID=MOVE_WEST_ID;
		if(isStopped()) start();
	    }
	    public Object getValue(String key){
		if(key==null) return null;
		if(key.equals(SMALL_ICON)) { 
		    return new ImageIcon
			(getClass().getResource("images/left.gif"));
		} else if(key.equals(SHORT_DESCRIPTION)){
		    return "Move westward";
		}
		return null;
	    }
	};

    public Action moveNorth=new AbstractAction(){
	    public void actionPerformed(ActionEvent e){
		actionID=MOVE_NORTH_ID;
		if(isStopped()) start();
	    }
	    public Object getValue(String key){
		if(key==null) return null;
		if(key.equals(SMALL_ICON)) {
		    return new ImageIcon
			(getClass().getResource("images/down.gif"));
		} else if(key.equals(SHORT_DESCRIPTION)){
		    return "Move southward";
		}		
		return null;
	    }
	};

    public Action moveSouth=new AbstractAction(){
	    public void actionPerformed(ActionEvent e){
		actionID=MOVE_SOUTH_ID;
		if(isStopped()) start();
	    }
	    public Object getValue(String key){
		if(key==null) return null;
		if(key.equals(SMALL_ICON)) {
		    return new ImageIcon
			(getClass().getResource("images/up.gif"));
		} else if(key.equals(SHORT_DESCRIPTION)){
		    return "Move northward";
		}
		return null;
	    }
	};

    public Action invert=new AbstractAction(){
	    public void actionPerformed(ActionEvent e){
		actionID=INVERT_ID;
		operate(actionID);
	    }
	    public Object getValue(String key){
		if(key==null) return null;
		if(key.equals(SMALL_ICON)) {
		    return new ImageIcon
			(getClass().getResource("images/invert.gif"));
		} else if(key.equals(SHORT_DESCRIPTION)){
		    return "Invert";
		}
		return null;
	    }
	};

    public Action blur=new AbstractAction(){
	    public void actionPerformed(ActionEvent e){
		actionID=BLUR_ID;
		operate(actionID);
	    }
	    public Object getValue(String key){
		if(key==null) return null;
		if(key.equals(SMALL_ICON)) {
		    return new ImageIcon
			(getClass().getResource("images/blur.gif"));
		} else if(key.equals(SHORT_DESCRIPTION)){
		    return "Blur";
		}
		return null;
	    }
	};

    public Action sharpen=new AbstractAction(){
	    public void actionPerformed(ActionEvent e){
		actionID=SHARPEN_ID;
		operate(actionID);
	    }
	    public Object getValue(String key){
		if(key==null) return null;
		if(key.equals(SMALL_ICON)) {
		    return new ImageIcon
			(getClass().getResource("images/sharpen.gif"));
		} else if(key.equals(SHORT_DESCRIPTION)){
		    return "Sharpen";
		}
		return null;
	    }
	};

    public Action edge=new AbstractAction(){
	    public void actionPerformed(ActionEvent e){
		actionID=EDGE_ID;
		operate(actionID);
	    }
	    public Object getValue(String key){
		if(key==null) return null;
		if(key.equals(SMALL_ICON)) {
		    return new ImageIcon
			(getClass().getResource("images/edge.gif"));
		} else if(key.equals(SHORT_DESCRIPTION)){
		    return "Edge";
		}
		return null;
	    }
	};

    public Action poster=new AbstractAction(){
	    public void actionPerformed(ActionEvent e){
		actionID=POSTER_ID;
		operate(actionID);
	    }
	    public Object getValue(String key){
		if(key==null) return null;
		if(key.equals(SMALL_ICON)) {
		    return new ImageIcon
			(getClass().getResource("images/poster.gif"));
		} else if(key.equals(SHORT_DESCRIPTION)){
		    return "Posterize";
		}
		return null;
	    }
	};

    public Action threshold=new AbstractAction(){
	    public void actionPerformed(ActionEvent e){
		actionID=THRESHOLD_ID;
		operate(actionID);
	    }
	    public Object getValue(String key){
		if(key==null) return null;
		if(key.equals(SMALL_ICON)) {
		    return new ImageIcon
			(getClass().getResource("images/threshold.gif"));
		} else if(key.equals(SHORT_DESCRIPTION)){
		    return "Threshold";
		}
		return null;
	    }
	};

    private BufferedImage buffImage;
    private double amin = Misc.AMIN;
    private double amax = Misc.AMAX;
    private double bmin = Misc.BMIN;
    private double bmax = Misc.BMAX;
    private double alen=amax-amin, blen=bmax-bmin;
    private double a=0.0, b=0.0, x=0.0, y=0.0;
    private double acenter,bcenter;
    private int zoomin=10;
    private int scaledA,scaledB;
    private int width,height;
    private Image image;
    private BufferedImage bi;
    int[] pixels;
    int[][] iterationTimes,newIterationTimes;
    private MemoryImageSource source;
    int red = 0xff;
    int green = 0xff;
    int blue = 0xff;
    int times = 255;
    private boolean firstTime=true;
    private int redSign=1, greenSign=1, blueSign=1;
    private boolean changeColor=true;
    Hashtable mOps = new Hashtable();
    private BufferedImageOp op;
    private boolean moveLeft=false,moveRight=false,moveUp=false,moveDown=true;
    private boolean faster=false;
    
    Mandelbrot(int width, int height) {
	this.width=width;
	this.height=height;
	buffImage=new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
	pixels = new int[width*height];
	iterationTimes = new int[width][height];
	newIterationTimes = new int[width][height];
	addMouseListener();
	mOps.put(new Integer(SHARPEN_ID), 
		 new ConvolveOp(new Kernel(3,3,Misc.sharpKernel),
				ConvolveOp.EDGE_NO_OP,null));
	mOps.put(new Integer(BLUR_ID),
		 new ConvolveOp(new Kernel(3,3,Misc.blurKernel)));
	mOps.put(new Integer(EDGE_ID),
		 new ConvolveOp(new Kernel(3,3,Misc.edgeKernel)));
	short[] invert = new short[256];
	short[] posterize = new short[256];
	short[] threshold = new short[256];
	for(int i=0;i<256;i++){
	    invert[i]=(short)(255-i);
	    posterize[i]=(short)(i-(i%128));
	    if(i<128) {
		threshold[i]=(short)0;
	    } else {
		threshold[i]=(short)255;
	    }
	}
	mOps.put(new Integer(INVERT_ID),
		 new LookupOp(new ShortLookupTable(0,invert),null));
	mOps.put(new Integer(POSTER_ID), 
		 new LookupOp(new ShortLookupTable(0,posterize),null));
	mOps.put(new Integer(THRESHOLD_ID), 
		 new LookupOp(new ShortLookupTable(0,threshold),null));
    }

    void setSleepTime(int sleepTime) {
	this.sleepTime = sleepTime;
    }

    int getSleepTime() {
	return sleepTime;
    }

    void renewIterationTimes(){
	for(int i=0; i<width; i++) {
	    for(int j=0; j<height; j++) {
		iterationTimes[i][j] = newIterationTimes[i][j];
	    }
	}
    }

    private void operate(int id){
	stop();
	op=(BufferedImageOp)mOps.get(new Integer(id));
	paintComponent(buffImage.getGraphics());
	bi=op.filter(buffImage, bi);
	image=(Image)bi;
	repaint();
    }

    public void start() {
	if(mainThread==null) {
	    mainThread=new Thread(this);
	    mainThread.setPriority(Thread.MIN_PRIORITY);
	    mainThread.start();
	    EventQueue.invokeLater(new Runnable() {
		    public void run() {
			pause.setEnabled(true);
		    }
		});
	}
    }

    public void stop() {
	if(mainThread != null) {
	    mainThread.interrupt();
	    mainThread=null;
	}
	EventQueue.invokeLater(new Runnable() {
		public void run() {
		    pause.setEnabled(false);
		}
	    });
    }

    public boolean isStopped(){
	return mainThread==null;
    }

    public void run() {
	while(mainThread==Thread.currentThread()){	    
	    if(index==1){
		paint1();
	    }
	    else if(index==2){
		paint2();
	    }
	    else if(index>=3){
		paint3();
	    }
	    index++;
	}
    }

    public void paintComponent(Graphics g) {
	super.paintComponent(g);
	update(g);
    }

    public void update(Graphics g) {
	Graphics2D g2 = (Graphics2D) g;
	g2.setFont(font);
	if(image!=null) {
	    g2.drawImage(image,0,0,width,height,this);
	    if(showWaitMessage) {
		g2.setColor(Color.black);
		int xpos=width/2-50, ypos=height/2;
		g2.drawString("WAIT...",
			      Misc.toEast(xpos,2),
			      Misc.toSouth(ypos,2));
		g2.setColor(Color.yellow);
		g2.drawString("WAIT...",xpos,ypos);
	    }
	}
    }

    private void getMandelbrot
	(double amin, double amax, double bmin, double bmax,
	 double xmin, double xmax, double ymin, double ymax) {

	double deltaA=(amax-amin)/width;
	double deltaB=(bmax-bmin)/height;
	for(a=xmin;a<xmax;a+=deltaA) {
	    for(b=ymin;b<ymax;b+=deltaB) {
		x=0.0;
		y=0.0;
		int iteration=0;
		while((x*x+y*y<=4.0) && (iteration!=times)) {
		    double x1 = xmapMandelbrot(x,y,a);
		    double y1 = ymapMandelbrot(x,y,b);
		    x = x1;
		    y = y1;
		    iteration ++;
		}
		if(iteration<=times && iteration>0) {
		    scaledA=scaleX(a,amin,amax);
		    scaledB=scaleY(b,bmin,bmax);
		    newIterationTimes[scaledA][scaledB]=iteration;
		}
	    }
	}
    }

    private double xmapMandelbrot(double x, double y, double a) {
	return x*x-y*y+a;
    }

    private double ymapMandelbrot(double x, double y, double b) {
	return 2.0*x*y+b;
    }

    private int scaleX(double x, double xmin, double xmax)  {
	int ivalue;
	if( x >= xmin && x < xmax ) {
	    ivalue = (int) ((x - xmin)*width/(xmax - xmin));
	}
	else {
	    ivalue=0;
	}
	return ivalue;
    }

    private int scaleY(double y, double ymin, double ymax)  {
	int jvalue;
	if( y >= ymin && y < ymax ) {
	    jvalue = (int) ((y - ymin)*height/(ymax - ymin));
	}
	else {
	    jvalue=0;
	}
	return jvalue;
    }
    
    public void resetScope(){
	stop();
	amin=Misc.AMIN;amax=Misc.AMAX;
	bmin=Misc.BMIN;bmax=Misc.BMAX;
	alen=amax-amin;blen=bmax-bmin;
	paint1();
	paint2();
	index=0;
    }
    
    void pauseColorAlternation(){
	changeColor=false;
    }

    void resumeColorAlternation(){
	changeColor=true;
    }

    public void setCursor(final Cursor c) {
	EventQueue.invokeLater(new Runnable() {
		public void run() {
		    Mandelbrot.super.setCursor(c);
		}
	    });
    }

    void paint1(){
	setCursor(waitCursor);
	int incr=0;
	for(int iy=0;iy<height;iy++){
	    for(int ix=0;ix<width;ix++){
		pixels[incr++]
		    =0xff<<24 | 0x00<<16 | 0x00<< 8 | 0xff;
	    }
	}
	if(firstTime) {
	    source=new MemoryImageSource(width,height,pixels,0,width);
	    firstTime=false;
	}
	else {
	    source.newPixels(0,0,width,height);
	}
	image=createImage(source);
	repaint();
	setCursor(defaultCursor);
    }

    void paint2(){
	setCursor(waitCursor);
	red   = (int)(Math.random()*255);
	green = (int)(Math.random()*255);
	blue  = (int)(Math.random()*255);
	getMandelbrot(amin,amax,bmin,bmax,amin,amax,bmin,bmax);
	renewIterationTimes();
	for(int ix=0;ix<width;ix++){
	    for(int iy=0;iy<height;iy++){
		pixels[iy*width+ix]=
		    0xff<<24 | red<<16 | 
		    iterationTimes[ix][iy]<<8 | blue;
	    }
	}
	source.newPixels(0,0,width,height);
	image=createImage(source);
	repaint();
	setCursor(defaultCursor);
    }
    
    private void paint3(){

	if(actionID!=MOVE_EAST_ID &&
	   actionID!=MOVE_WEST_ID &&
	   actionID!=MOVE_NORTH_ID &&
	   actionID!=MOVE_SOUTH_ID) return;

	try {
	    Thread.sleep(sleepTime);
	} catch(InterruptedException e){}

	if(changeColor){
	    
	    if(red==255) redSign=-1;
	    else if(red==0) redSign=1;
	    if(green==255) greenSign=-1;
	    else if(green==0) greenSign=1;
	    if(blue==255) blueSign=-1;
	    else if(blue==0) blueSign=1;
	    red+=redSign;
	    green+=greenSign;
	    blue+=blueSign;

	}
	
	int shift=1;
	double slot=shift*alen/width;
	switch(actionID){
	case MOVE_EAST_ID:
	    for(int i=0;i<width;i++){
		for(int j=0;j<height;j++){
		    if(i-shift>=0){
			newIterationTimes[i][j]=iterationTimes[i-shift][j];
		    }
		}
	    }
	    amin-=slot;
	    amax-=slot;
	    getMandelbrot(amin,amax,bmin,bmax,amin,amin+slot,bmin,bmax);
	    break;
	case MOVE_WEST_ID:
	    for(int i=0;i<width;i++){
		for(int j=0;j<height;j++){
		    if(i+shift<width){
			newIterationTimes[i][j]=iterationTimes[i+shift][j];
		    }
		}
	    }
	    amin+=slot;
	    amax+=slot;
	    getMandelbrot(amin,amax,bmin,bmax,amax-slot,amax,bmin,bmax);
	    break;
	case MOVE_NORTH_ID:
	    for(int i=0;i<width;i++){
		for(int j=0;j<height;j++){
		    if(j-shift>=0){
			newIterationTimes[i][j]=iterationTimes[i][j-shift];
		    }
		}
	    }
	    bmin-=slot;
	    bmax-=slot;
	    getMandelbrot(amin,amax,bmin,bmax,amin,amax,bmin,bmin+slot);
	    break;
	case MOVE_SOUTH_ID:
	    for(int i=0;i<width;i++){
		for(int j=0;j<height;j++){
		    if(j+shift<height){
			newIterationTimes[i][j]=iterationTimes[i][j+shift];
		    }
		}
	    }
	    bmin+=slot;
	    bmax+=slot;
	    getMandelbrot(amin,amax,bmin,bmax,amin,amax,bmax-slot,bmax);
	    break;
	}
	renewIterationTimes();

	for(int ix=0; ix<width; ix++){
	    for(int iy=0; iy<height; iy++){
		pixels[iy*width+ix]= 0xff<<24 | red<<16 | iterationTimes[ix][iy]<<8 | blue;
	    }
	}
	source.newPixels(0,0,width,height);
	image=createImage(source);
	repaint();

    }
    
    public void addMouseListener(){
	addMouseListener(mouseAdapter);
    }

    public void removeMouseListener(){
	removeMouseListener(mouseAdapter);
    }

    void setCenter(double xCenter, double yCenter) {
	alen=amax-amin;
	blen=bmax-bmin;
	paint1();
	paint2();
    }

    private void setCenter2(double xCenter, double yCenter) {
	amin=xCenter-alen/zoomin;
	amax=xCenter+alen/zoomin;
	bmin=yCenter-blen/zoomin;
	bmax=yCenter+blen/zoomin;
	alen=amax-amin;
	blen=bmax-bmin;
	if(Math.max(alen,blen)<0.000000000001) {
	    amax=Misc.AMAX;amin=Misc.AMIN;
	    bmin=Misc.BMIN;bmax=Misc.BMAX;
	    alen=amax-amin;blen=bmax-bmin;
	}
	paint1();
	paint2();
    }

    void setXmin(double x) {
	amin=x;
    }

    double getXmin() {
	return amin;
    }

    void setXmax(double x) {
	amax=x;
    }

    double getXmax() {
	return amax;
    }

    void setYmin(double x) {
	bmin=x;
    }

    double getYmin() {
	return bmin;
    }

    void setYmax(double x) {
	bmax=x;
    }

    double getYmax() {
	return bmax;
    }

    float[] getCenter() {
	if(acenter==0) acenter=amin+0.5*alen;
	if(bcenter==0) bcenter=bmin+0.5*blen;
	return new float[] {(float)acenter, (float)bcenter};
    }

    private MouseAdapter mouseAdapter=new MouseAdapter(){

	    public void mousePressed (MouseEvent e) {

		stop();
		if((e.getModifiers() & MouseEvent.BUTTON1_MASK)!=0){
		    int x=e.getX();
		    int y=e.getY();
		    if(x>width) {x=width;}
		    if(x<0) {x=0;}
		    if(y>height) {y=height;}
		    if(y<0) {y=0;}
		    acenter=((double) x/(double) width)*alen+amin;
		    bcenter=((double) y/(double) height)*blen+bmin;
		    setCenter2(acenter, bcenter);
		} else if((e.getModifiers() & MouseEvent.BUTTON3_MASK)!=0){

		}

	    }

	};

}
