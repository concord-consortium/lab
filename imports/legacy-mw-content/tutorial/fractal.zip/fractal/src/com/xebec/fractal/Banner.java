/*
 *   Copyright (C) 2006  The Concord Consortium, Inc.,
 *   25 Love Lane, Concord, MA 01742
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * END LICENSE */

package com.xebec.fractal;

import java.awt.Color;
import java.awt.FontMetrics;
import java.awt.Graphics;

import javax.swing.JComponent;

class Banner extends JComponent {

    public void paintComponent(Graphics g) {

	super.paintComponent(g);

	int width=getWidth();
	int height=getHeight();
	g.setColor(new Color(204,204,204));
	g.fillRect(0, 0, width, height);

	int x = (int)(width/10.0), y = (int)(height/1.4);
	g.setFont(Misc.bigFont);
	g.setColor(Color.white);
	g.drawString("Mandelbrot World", Misc.toEast(x,1), Misc.toSouth(y,1));
	g.drawString("Mandelbrot World", Misc.toEast(x,1), Misc.toNorth(y,1));
	g.drawString("Mandelbrot World", Misc.toWest(x,1), Misc.toSouth(y,1));
	g.drawString("Mandelbrot World", Misc.toWest(x,1), Misc.toNorth(y,1));
	g.setColor(Color.black);
	g.drawString("Mandelbrot World",x,y);

	g.setFont(Misc.smallFont);
	g.setColor(Color.blue);
	String s="Charles Xie (c) 1999";	
	g.drawString(s, width-10-g.getFontMetrics().stringWidth(s), y);
	
    }

}





