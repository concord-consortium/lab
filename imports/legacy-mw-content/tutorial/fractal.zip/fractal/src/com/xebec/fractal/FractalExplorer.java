/*
 *   Copyright (C) 2006  The Concord Consortium, Inc.,
 *   25 Love Lane, Concord, MA 01742
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * END LICENSE */

package com.xebec.fractal;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.InputStream;
import java.io.IOException;
import java.io.OutputStream;

import javax.swing.Action;
import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JApplet;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.SwingConstants;
import javax.swing.border.BevelBorder;
import javax.swing.border.EtchedBorder;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import org.xml.sax.helpers.DefaultHandler;

import org.concord.modeler.MwService;

/**  A Mandelbrot set explorer.
 *
 *   @author Qian Xie, 1999
 */

public class FractalExplorer extends JApplet implements MwService {

    public final static int DEFAULT_WIDTH=300, DEFAULT_HEIGHT=300;

    private Mandelbrot mandelbrot;
    private JFileChooser fc;
    private static Dimension prefdim=new Dimension(DEFAULT_WIDTH, DEFAULT_HEIGHT);
    private SAXParser saxParser;
    private DefaultHandler saxHandler;

    public FractalExplorer(){
	//setMaximumSize(new Dimension(DEFAULT_WIDTH+70, DEFAULT_HEIGHT+50));
	try {
	    saxParser = SAXParserFactory.newInstance().newSAXParser();
	}
	catch (SAXException e) {
	    e.printStackTrace(System.err);
	    return;
	}
	catch (ParserConfigurationException e) {
	    e.printStackTrace(System.err);
	    return;
	}
	saxHandler = new XMLHandler();
    }

    public void destroy() {
	super.destroy();
	if(mandelbrot!=null) {
	    mandelbrot.stop();
	}
    }

    public Component getSnapshotComponent() {
	return mandelbrot;
    }

    public void loadState(InputStream is) throws IOException {
	if(is==null) return;
	try {
	    saxParser.parse(new InputSource(is), saxHandler);
	}
	catch (IOException e) {
	    e.printStackTrace(System.err);
	}
	catch (SAXException e) {
	    e.printStackTrace(System.err);
	}
    }

    public void saveState(OutputStream os) throws IOException {
	if(os==null) return;
	StringBuffer sb=new StringBuffer(1000);
	sb.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
	sb.append("<state>");
	float[] val = mandelbrot.getCenter();
	sb.append("<xpos>"+val[0]+"</xpos>");
	sb.append("<ypos>"+val[1]+"</ypos>");
	sb.append("<xmin>"+mandelbrot.getXmin()+"</xmin>");
	sb.append("<xmax>"+mandelbrot.getXmax()+"</xmax>");
	sb.append("<ymin>"+mandelbrot.getYmin()+"</ymin>");
	sb.append("<ymax>"+mandelbrot.getYmax()+"</ymax>");
	sb.append("</state>");
	try {
	    os.write(sb.toString().getBytes());
	}
	catch (IOException e) {
	    e.printStackTrace(System.err);
	    javax.swing.JOptionPane.showMessageDialog(this, e.getMessage());
	}
	finally {
	    try {
		os.close();
	    }
	    catch (IOException e) {
		e.printStackTrace(System.err);
	    }
	}
    }

    public void init(){

	mandelbrot = new Mandelbrot(prefdim.width, prefdim.height);
	mandelbrot.setMinimumSize(prefdim);
	mandelbrot.setMaximumSize(prefdim);
	mandelbrot.setPreferredSize(prefdim);
	mandelbrot.setBorder(BorderFactory.createBevelBorder(BevelBorder.LOWERED));

	MouseListener[] ml=getMouseListeners();
	if(ml!=null && ml.length>0) {
	    for(int i=0; i<ml.length; i++) mandelbrot.addMouseListener(ml[i]);
	}
	
	JPanel leftPanel=new JPanel(new BorderLayout(10,10));

	JPanel panel=new JPanel(new GridLayout(5,2,0,0));
	panel.setBorder(BorderFactory.createEmptyBorder(5,5,5,5));
	panel.setPreferredSize(new Dimension(70, prefdim.height/2));

	ButtonGroup bg=new ButtonGroup();
	JRadioButton rButton;

	rButton=createButton(mandelbrot.moveEast);
	bg.add(rButton);
	panel.add(rButton);
	rButton=createButton(mandelbrot.moveWest);
	bg.add(rButton);
	panel.add(rButton);
	rButton=createButton(mandelbrot.moveNorth);
	bg.add(rButton);
	panel.add(rButton);
	rButton=createButton(mandelbrot.moveSouth);
	bg.add(rButton);
	panel.add(rButton);

	JButton button=new JButton(mandelbrot.invert);
	button.setFont(Misc.smallFont);
	button.setHorizontalAlignment(SwingConstants.CENTER);
	button.setBorderPainted(true);
	button.setBorder(Misc.aButtonBorder);
	panel.add(button);

	button=new JButton(mandelbrot.blur);
	button.setFont(Misc.smallFont);
	button.setHorizontalAlignment(SwingConstants.CENTER);
	button.setBorderPainted(true);
	button.setBorder(Misc.aButtonBorder);
	panel.add(button);

	button=new JButton(mandelbrot.sharpen);
	button.setHorizontalAlignment(SwingConstants.CENTER);
	button.setBorderPainted(true);
	button.setBorder(Misc.aButtonBorder);
	button.setFont(Misc.smallFont);
	panel.add(button);

	button=new JButton(mandelbrot.edge);
	button.setFont(Misc.smallFont);
	button.setHorizontalAlignment(SwingConstants.CENTER);
	button.setBorderPainted(true);
	button.setBorder(Misc.aButtonBorder);
	panel.add(button);

	button=new JButton(mandelbrot.poster);
	button.setFont(Misc.smallFont);
	button.setHorizontalAlignment(SwingConstants.CENTER);
	button.setBorderPainted(true);
	button.setBorder(Misc.aButtonBorder);
	panel.add(button);

	button=new JButton(mandelbrot.threshold);
	button.setFont(Misc.smallFont);
	button.setHorizontalAlignment(SwingConstants.CENTER);
	button.setBorderPainted(true);
	button.setBorder(Misc.aButtonBorder);
	panel.add(button);

	leftPanel.add(panel, BorderLayout.NORTH);

	panel=new JPanel();
	panel.setBorder(BorderFactory.createEmptyBorder(5,5,5,5));

	leftPanel.add(panel, BorderLayout.CENTER);
	
	JPanel buttonPanel=new JPanel();
	buttonPanel.setBorder(BorderFactory.createMatteBorder(0,0,1,1,Color.black));    

	button=new JButton("Reset",new ImageIcon(getClass().getResource("images/back.gif")));
	button.setToolTipText("Reset");
	button.addActionListener(new ActionListener(){
		public void actionPerformed(ActionEvent e){
		    mandelbrot.resetScope();
		}
	    });
	buttonPanel.add(button);

	button=new JButton(mandelbrot.pause);
	button.setToolTipText("Stop moving");
	buttonPanel.add(button);
    
	Banner banner = new Banner();
	banner.setPreferredSize(new Dimension(DEFAULT_WIDTH, 30));
	banner.setBorder(BorderFactory.createEtchedBorder(EtchedBorder.LOWERED));

	getContentPane().setLayout(new BorderLayout());
	getContentPane().add(banner, BorderLayout.NORTH);
	getContentPane().add(leftPanel, BorderLayout.WEST);
	getContentPane().add(mandelbrot, BorderLayout.CENTER);
	getContentPane().add(buttonPanel, BorderLayout.SOUTH);

	mandelbrot.paint1();
	mandelbrot.paint2();
    
    }

    public void stop(){
	mandelbrot.stop();
    }

    private JRadioButton createButton(Action action){
	JRadioButton rButton=new JRadioButton(action);
	rButton.setIcon((ImageIcon)(rButton.getAction().getValue(Action.SMALL_ICON)));
	rButton.setToolTipText((String)(rButton.getAction().getValue(Action.SHORT_DESCRIPTION)));
	rButton.setHorizontalAlignment(SwingConstants.CENTER);
	rButton.setBorderPainted(true);
	rButton.setFont(Misc.smallFont);
	rButton.setBorder(Misc.aButtonBorder);
	rButton.addItemListener(new PressListener(rButton));
	return rButton;
    }

    public JMenuBar createMenuBar(){

	fc=new JFileChooser(System.getProperty("user.dir"));
	fc.addChoosableFileFilter(new ImageFilter());
	fc.setFileView(new ImageFileView());

	JMenuBar menuBar=new JMenuBar();

	JMenu menu=new JMenu("File");
	menu.setFont(Misc.font);
	
    	JMenuItem menuItem=new JMenuItem("Save", new ImageIcon(getClass().getResource("images/save.gif")));
	menuItem.setFont(Misc.font);
	menuItem.addActionListener(new ActionListener(){
		public void actionPerformed(ActionEvent e){
		    mandelbrot.pauseColorAlternation();
		    int returnValue=fc.showSaveDialog(FractalExplorer.this);
		    if(returnValue==JFileChooser.APPROVE_OPTION) {
			File file=fc.getSelectedFile();
			Misc.saveItAsJPEG(mandelbrot,file.getName());
		    }
		    mandelbrot.resumeColorAlternation();
		}
	    });
	menu.add(menuItem);

	menuBar.add(menu);

	return menuBar;

    }

    private class PressListener implements ItemListener {

	private JRadioButton button;

	PressListener(JRadioButton r){
	    button=r;
	}
	
	public void itemStateChanged(ItemEvent e){
	    if(e.getStateChange()==ItemEvent.SELECTED){
		button.setBorder(Misc.bButtonBorder);
		button.setBackground(Color.white);
	    } else {
		button.setBorder(Misc.aButtonBorder);
		button.setBackground(new Color(204,204,204));
	    }
	}

    }

    public static void main(String[] args){

        Dimension screen=Toolkit.getDefaultToolkit().getScreenSize();

	FractalExplorer applet = new FractalExplorer();
	applet.init();

	JFrame frame=new JFrame("Mandelbrot Set Explorer");
        frame.setLocation((screen.width-DEFAULT_WIDTH)/2, (screen.height-DEFAULT_HEIGHT)/2);
	frame.addWindowListener(new WindowAdapter(){
		public void windowClosing(WindowEvent e){
		    System.exit(0);
		}
	    });
	frame.getContentPane().setLayout(new BorderLayout());
	frame.getContentPane().add(applet,BorderLayout.CENTER);
	frame.setJMenuBar(applet.createMenuBar());
	frame.setSize(new Dimension(DEFAULT_WIDTH, DEFAULT_HEIGHT));
	frame.setResizable(false);
	frame.pack();
	frame.setVisible(true);

    }

    class XMLHandler extends DefaultHandler {

	private float xpos, ypos;
	private double xmin, xmax, ymin, ymax;
	private String str;

	public void startDocument() {
	}
	
	public void endDocument() {
	    if(xmin!=0) {
		mandelbrot.setXmin(xmin);
	    }
	    if(xmax!=0) {
		mandelbrot.setXmax(xmax);
	    }
	    if(ymin!=0) {
		mandelbrot.setYmin(ymin);
	    }
	    if(ymax!=0) {
		mandelbrot.setYmax(ymax);
	    }
	    mandelbrot.setCenter(xpos, ypos);
	}
	
	public void startElement
	    (String uri, String localName, String qName, Attributes attrib) {
	}
	
	public void endElement(String uri, String localName, String qName) {
	    if(qName=="xpos") {
		xpos=Float.parseFloat(str);
	    }
	    else if(qName=="ypos") {
		ypos=Float.parseFloat(str);
	    }
	    else if(qName=="xmin") {
		xmin=Double.parseDouble(str);
	    }
	    else if(qName=="xmax") {
		xmax=Double.parseDouble(str);
	    }
	    else if(qName=="ymin") {
		ymin=Double.parseDouble(str);
	    }
	    else if(qName=="ymax") {
		ymax=Double.parseDouble(str);
	    }
	}
	
	public void characters(char[] ch, int start, int length) {
	    str=new String(ch, start, length);
	}

	public void warning(SAXParseException e) {
	    e.printStackTrace(System.err);
	}
	
	public void error(SAXParseException e) {
	    e.printStackTrace(System.err);
	}
	
	public void fatalError(SAXParseException e) {
	    e.printStackTrace(System.err);
	}

    }

}
