/*
 *   Copyright (C) 2006  The Concord Consortium, Inc.,
 *   25 Love Lane, Concord, MA 01742
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * END LICENSE */

package com.xebec.fractal;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

import javax.swing.plaf.basic.BasicBorders;

import com.sun.image.codec.jpeg.JPEGCodec;
import com.sun.image.codec.jpeg.JPEGImageEncoder;

abstract class Misc {

    public static final double AMIN=-2.0, AMAX= 1.0, BMIN=-1.5, BMAX= 1.5; 

    public static final Font tinyFont=new Font("Arial",Font.BOLD,8);
    public static final Font smallFont=new Font("Arial",Font.BOLD,9);
    public static final Font font=new Font("Arial",Font.PLAIN,11);
    public static final Font bigFont=new Font("TimesRoman",Font.BOLD,20);

    public static final float ninth=1.0f/9.0f;
    public static final float[] blurKernel={ninth, ninth, ninth,
					    ninth, ninth, ninth,
					    ninth, ninth, ninth};

    public static final float[] edgeKernel={0.0f, -1.0f,  0.0f,
					    -1.0f,  4.0f, -1.0f,
					    0.0f, -1.0f,  0.0f};

    public static final float[] sharpKernel={0.0f, -1.0f,  0.0f,
					     -1.0f,  5.0f, -1.0f,
					     0.0f, -1.0f,  0.0f};

    public final static BasicBorders.ButtonBorder aButtonBorder=
	new BasicBorders.ButtonBorder
	(Color.gray,Color.black,Color.white,Color.lightGray);

    public final static BasicBorders.ButtonBorder bButtonBorder=
	new BasicBorders.ButtonBorder
	(Color.lightGray,Color.white,Color.black,Color.gray);

    public static String getExtension(File file){
	String ext = null;
	String str = file.getName();
	int i = str.lastIndexOf('.');
	if(i>0 && i<str.length()-1){
	    ext=str.substring(i+1).toLowerCase();
	}
	return ext;
    }

    static int toNorth(int current, int distance){return current-distance;}
    static int toSouth(int current, int distance){return current+distance;}
    static int  toEast(int current, int distance){return current+distance;}
    static int  toWest(int current, int distance){return current-distance;}

    static void saveItAsJPEG(Mandelbrot screenshot, String fileName) {
	if(fileName==null) return;
	Dimension size = screenshot.getSize();
	BufferedImage buff = new BufferedImage(size.width,size.height,
				 BufferedImage.TYPE_INT_RGB);
	Graphics g = buff.getGraphics();
	screenshot.paintComponent(g);
	try {
	    OutputStream out = new FileOutputStream(fileName);
	    JPEGImageEncoder encoder = JPEGCodec.createJPEGEncoder(out);
	    encoder.encode(buff);
	    out.close();
	} catch (Exception e) {
	}
    }

}

